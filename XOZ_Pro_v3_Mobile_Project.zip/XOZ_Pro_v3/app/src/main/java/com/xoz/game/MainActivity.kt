package com.xoz.game

import android.app.*
import android.os.*
import android.graphics.Color
import android.media.ToneGenerator
import android.media.AudioManager
import android.view.*
import android.widget.*
import android.content.Context
import kotlin.math.max
import kotlin.random.Random

class MainActivity: Activity(){
    lateinit var root:LinearLayout
    lateinit var board:GridLayout
    lateinit var status:TextView
    lateinit var prefs:android.content.SharedPreferences
    var cells=Array(9){""}; var human="X"; var ai="O"; var turn="X"; var over=false
    var xScore=0; var oScore=0; var difficulty=1; var vsComputer=true
    val tone=ToneGenerator(AudioManager.STREAM_MUSIC,90)
    val bs=ArrayList<Button>()

    override fun onCreate(b:Bundle?){
        super.onCreate(b)
        prefs=getSharedPreferences("xoz_stats",Context.MODE_PRIVATE)
        xScore=prefs.getInt("x",0); oScore=prefs.getInt("o",0)
        home()
    }

    fun base():LinearLayout=LinearLayout(this).apply{
        orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;padding=18
        setBackgroundColor(Color.rgb(7,17,31))
    }
    fun txt(s:String,n:Float=18f)=TextView(this).apply{
        text=s;textSize=n;setTextColor(Color.WHITE);gravity=Gravity.CENTER;padding=10
    }
    fun btn(s:String)=Button(this).apply{text=s;textSize=17f;isAllCaps=false}

    fun home(){
        root=base()
        root.addView(txt("XOZ",44f)); root.addView(txt("فكّر • خطّط • اربح",18f))
        root.addView(btn("🤖 ضد الكمبيوتر").apply{setOnClickListener{chooseDifficulty()}})
        root.addView(btn("👥 لاعبان").apply{setOnClickListener{vsComputer=false;startGame(true)}})
        root.addView(btn("🏆 الإحصائيات").apply{setOnClickListener{stats()}})
        root.addView(btn("⚙️ الإعدادات").apply{setOnClickListener{settings()}})
        root.addView(btn("ℹ️ عن اللعبة").apply{setOnClickListener{about()}})
        setContentView(root)
    }

    fun chooseDifficulty(){
        root=base();root.addView(txt("اختر مستوى الصعوبة",28f))
        listOf("سهل 😊","متوسط 😎","صعب 🔥").forEachIndexed{idx,s->
            root.addView(btn(s).apply{setOnClickListener{difficulty=idx+1;chooseSymbol()}})
        }
        root.addView(btn("رجوع").apply{setOnClickListener{home()}});setContentView(root)
    }

    fun chooseSymbol(){
        root=base();root.addView(txt("اختار رمزك",28f))
        root.addView(btn("❌ أنا X").apply{setOnClickListener{human="X";ai="O";startGame(true)}})
        root.addView(btn("⭕ أنا O").apply{setOnClickListener{human="O";ai="X";startGame(false)}})
        root.addView(btn("رجوع").apply{setOnClickListener{chooseDifficulty()}});setContentView(root)
    }

    fun startGame(humanStarts:Boolean){
        root=base()
        root.addView(txt("XOZ",28f))
        status=txt("",18f);root.addView(status)
        board=GridLayout(this).apply{columnCount=3;rowCount=3}
        bs.clear()
        for(i in 0..8){
            val q=btn("")
            q.textSize=30f
            q.setTextColor(Color.WHITE)
            q.layoutParams=GridLayout.LayoutParams().apply{width=100;height=100;setMargins(4,4,4,4)}
            q.setOnClickListener{move(i)}
            bs.add(q);board.addView(q)
        }
        root.addView(board)
        root.addView(btn("🔄 إعادة الجولة").apply{setOnClickListener{startGame(humanStarts)}})
        root.addView(btn("⌂ الرئيسية").apply{setOnClickListener{home()}})
        setContentView(root)
        cells=Array(9){""};over=false
        turn=if(humanStarts)human else ai
        update()
        if(turn==ai) Handler(Looper.getMainLooper()).postDelayed({computer()},350)
    }

    fun move(i:Int){
        if(over||cells[i].isNotEmpty()||turn!=human)return
        put(i,human)
        if(!checkEnd()){
            turn=ai;update()
            if(vsComputer) Handler(Looper.getMainLooper()).postDelayed({computer()},280)
            else { turn=if(turn=="X")"O" else "X"; update() }
        }
    }

    fun put(i:Int,p:String){
        cells[i]=p;bs[i].text=if(p=="X")"❌" else "⭕"
        tone.startTone(ToneGenerator.TONE_PROP_BEEP,75)
    }

    fun computer(){
        if(over)return
        val empty=cells.indices.filter{cells[it].isEmpty()}
        if(empty.isEmpty())return
        val pick=when(difficulty){1->empty.random();2->bestMove(false);else->bestMove(true)}
        put(pick,ai)
        if(!checkEnd()){turn=human;update()}
    }

    fun bestMove(full:Boolean):Int{
        val empt=cells.indices.filter{cells[it].isEmpty()}
        if(!full && Random.nextInt(100)<55)return empt.random()
        var best=-999;var bi=empt.first()
        for(i in empt){
            cells[i]=ai;val v=minimax(false);cells[i]=""
            if(v>best){best=v;bi=i}
        }
        return bi
    }

    fun minimax(maximizing:Boolean):Int{
        if(winner(ai))return 10
        if(winner(human))return -10
        if(cells.all{it.isNotEmpty()})return 0
        val e=cells.indices.filter{cells[it].isEmpty()}
        return if(maximizing){
            var v=-999
            for(i in e){cells[i]=ai;v=max(v,minimax(false));cells[i]=""}
            v
        }else{
            var v=999
            for(i in e){cells[i]=human;v=kotlin.math.min(v,minimax(true));cells[i]=""}
            v
        }
    }

    fun winner(p:String):Boolean{
        val w=arrayOf(
            intArrayOf(0,1,2),intArrayOf(3,4,5),intArrayOf(6,7,8),
            intArrayOf(0,3,6),intArrayOf(1,4,7),intArrayOf(2,5,8),
            intArrayOf(0,4,8),intArrayOf(2,4,6)
        )
        return w.any{cells[it[0]]==p&&cells[it[1]]==p&&cells[it[2]]==p}
    }

    fun checkEnd():Boolean{
        if(winner(turn)){
            over=true
            if(turn=="X")xScore++ else oScore++
            saveStats();update();winSound()
            result(if(turn==human) "🎉 مبروك! لقد فزت" else "🤖 الكمبيوتر فاز")
            return true
        }
        if(cells.all{it.isNotEmpty()}){
            over=true;saveStats();update();drawSound()
            result("🤝 تعادل!")
            return true
        }
        return false
    }

    fun result(message:String){
        Handler(Looper.getMainLooper()).postDelayed({
            AlertDialog.Builder(this)
                .setTitle(message)
                .setMessage("النتيجة الحالية\n❌ $xScore    ⭕ $oScore")
                .setPositiveButton("لعبة جديدة"){_,_->startGame(human=="X")}
                .setNegativeButton("الرئيسية"){_,_->home()}
                .show()
        },220)
    }

    fun winSound(){
        tone.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD,120)
        Handler(Looper.getMainLooper()).postDelayed({tone.startTone(ToneGenerator.TONE_PROP_ACK,180)},150)
    }
    fun drawSound(){tone.startTone(ToneGenerator.TONE_PROP_NACK,220)}

    fun update(){
        if(::status.isInitialized){
            status.text=if(over)"انتهت الجولة" else
                "دور: "+if(turn=="X")"❌ X" else "⭕ O"+"    |    ❌ $xScore  ⭕ $oScore"
        }
    }

    fun saveStats(){
        prefs.edit().putInt("x",xScore).putInt("o",oScore).apply()
    }

    fun stats(){
        root=base();root.addView(txt("🏆 الإحصائيات",30f))
        root.addView(txt("إجمالي نقاط X: $xScore\nإجمالي نقاط O: $oScore",22f))
        root.addView(btn("🗑️ تصفير الإحصائيات").apply{
            setOnClickListener{
                xScore=0;oScore=0;saveStats();stats()
            }
        })
        root.addView(btn("رجوع").apply{setOnClickListener{home()}})
        setContentView(root)
    }

    fun settings(){
        root=base();root.addView(txt("⚙️ الإعدادات",30f))
        root.addView(txt("الصوت يعمل تلقائيًا أثناء اللعب.\nيمكن التحكم في صوت الهاتف من أزرار الجهاز.",17f))
        root.addView(btn("تصفير الإحصائيات").apply{setOnClickListener{xScore=0;oScore=0;saveStats();Toast.makeText(this,"تم التصفير",Toast.LENGTH_SHORT).show()}})
        root.addView(btn("رجوع").apply{setOnClickListener{home()}})
        setContentView(root)
    }

    fun about(){
        root=base();root.addView(txt("XOZ",42f));root.addView(txt("لعبة إكس أو عربية\nالإصدار 3.0\nفكّر • خطّط • اربح\n\nتم تصميمها لتعمل بدون إنترنت.",18f))
        root.addView(btn("رجوع").apply{setOnClickListener{home()}})
        setContentView(root)
    }

    override fun onDestroy(){tone.release();super.onDestroy()}
}