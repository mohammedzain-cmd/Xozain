plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace="com.xoz.game"; compileSdk=35
 defaultConfig { applicationId="com.xoz.game"; minSdk=23; targetSdk=35; versionCode=3; versionName="3.0" }
}
